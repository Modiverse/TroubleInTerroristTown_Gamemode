### How do I use it? ###

**KantanDocGen Automatic Documentation ([KantanDocGen](http://kantandev.com/free/kantan-doc-gen))** 

**[AdvancedSessions](https://mordentral.bitbucket.io/AdvancedSessions/Advanced)**

**[AdvancedSteamSessions](https://mordentral.bitbucket.io/AdvancedSteamSessions/Advanced)**
